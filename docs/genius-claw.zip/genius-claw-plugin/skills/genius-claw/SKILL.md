---
name: genius-claw
description: Genius Team orchestration for OpenClaw. Multi-project intelligence, cross-project memory, auto-updates, and a global dashboard. Use when the user mentions genius-team, wants to start/resume/manage a coding project with Genius Team, or asks about their projects status.
---

# Genius-Claw 🌀

Genius Team, orchestrated by OpenClaw. You are the director — you don't run the skills yourself, you guide the user's coding agent (Claude Code, Codex, etc.) to do so from within their project.

---

## 0. Before anything — Load user profile

Read `memory/genius-claw.md` from the OpenClaw workspace.
If it doesn't exist, create it from the template below and tell the user it's been initialized.

This file is your cross-project memory. Apply everything in it before starting any project session:
- Coding style preferences
- Universal rules and reflexes
- Anti-patterns to avoid
- Favorite stack and tools

---

## 1. Detect intent

**"Start a new project with Genius Team"** → go to §3 (new project)
**"Continue / resume [project]"** → go to §4 (resume)
**"Show my projects"** / **"Dashboard"** / **"status"** → go to §6 (global view)
**"Update Genius Team"** → go to §7 (manual update)

> **📊 PROACTIVE RULE**: After ANY interaction involving a project (start, resume, skill completion, session end), always offer the Dashboard:
> - **Per-project:** `open .genius/DASHBOARD.html` in the project folder (or `/genius-dashboard` to refresh)
> - **Global:** Present `genius-claw-dashboard.html` via Canvas or as a link
> Never wait for the user to ask. Mention it naturally at the end of your reply.

---

## 2. Load project registry

Read `memory/genius-claw-projects.json`. If it doesn't exist, create it as `[]`.

This registry tracks all active Genius Team projects. Always update it when:
- A new project is added
- A project changes phase
- A project is marked done

---

## 3. New project

1. Ask for the project path (or use current working directory if obvious)
2. Check if Genius Team is already installed (look for `.genius/` folder or `CLAUDE.md` with "Genius Team" header)
3. If not installed:
   ```bash
   cd <project-path>
   bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/add.sh)
   ```
4. Tell the user: "Genius Team is installed. Now open this project in Claude Code and type `/genius-interviewer` to begin."
5. Add to registry: `{ "name": "<project>", "path": "<path>", "version": "<detected>", "phase": "interview", "lastActive": "<now>" }`

---

## 4. Resume project

1. Read `.genius/state.json` in the project folder to know the current phase and progress
2. Apply the user profile from `memory/genius-claw.md`
3. Check project's **Auto Memory** (`~/.claude/projects/<project>/memory/MEMORY.md`) for recent learnings — these complement the `.genius/` team-shared memory
4. Tell the user where the project left off and what the next step is
5. Update `lastActive` in the registry
6. **Always** proactively offer the Dashboard at the end:
   ```
   📊 Want to see your full project Dashboard?
   → open .genius/DASHBOARD.html  (or run /genius-dashboard to refresh)
   ```
   Present it via Canvas if available: `canvas(action=present, url="file://<project>/.genius/DASHBOARD.html")`

---

## 5. Post-session learning (run after any project session)

After a coding session, extract and persist learnings:

**Extract from the session:**
- Corrections the user made (→ rule to add)
- Patterns the user approved (→ reinforce)
- Recurring friction points (→ anti-pattern to note)

**Update `memory/genius-claw.md`** — append to relevant sections, don't overwrite.

**Update project registry** — update phase and lastActive.

**Always announce Dashboard update at the end of every session:**
```
📊 Dashboard updated → open .genius/DASHBOARD.html
   (or run /genius-dashboard to refresh with latest playgrounds)
```
Use Canvas to present it directly if available.

---

## 5b. Claude Code Native Memory — Key facts

Claude Code (as of 2025) has **two native memory systems** that complement Genius Team:

| Layer | Location | Auto-loaded? | Best for |
|-------|----------|-------------|---------|
| **Auto Memory** | `~/.claude/projects/<project>/memory/MEMORY.md` | ✅ Yes (200 lines) | Personal learnings, debug insights, patterns |
| **CLAUDE.md import** | `@.genius/memory/BRIEFING.md` in CLAUDE.md | ✅ Yes (native import) | Project context, team decisions |
| **`.claude/rules/`** | `.claude/rules/*.md` | ✅ Yes (all files) | Modular topic rules, path-scoped conventions |
| **`CLAUDE.local.md`** | Project root | ✅ Yes (gitignored) | Personal local prefs (URLs, ports, tokens) |

**As Genius-Claw director, leverage these:**
- Tell users: "say `remember that...` to Claude Code to save patterns to Auto Memory"
- BRIEFING.md is loaded natively via `@import` — no manual load needed
- Suggest `CLAUDE.local.md` for personal dev server URLs and local config

## 6. Global dashboard

Open (or generate) the global dashboard:
- Location: `<workspace>/genius-claw-dashboard.html`
- Content: all projects from the registry, with phase, progress, last activity, and a link to each project's local dashboard

If the file doesn't exist or is stale, regenerate it:
```
For each project in registry:
  - Show project name, path, current phase, days since last activity
  - Badge: 🟢 active | 🟡 stale (>3 days) | ⚫ done
  - Click → opens that project's .genius/DASHBOARD.html
```

Then serve it. Choose the right method based on context:

**Option A — OpenClaw Canvas (fastest, works local & remote)**
Use the `canvas` tool to present the HTML directly inside OpenClaw:
```
canvas(action=present, url="file://<workspace>/genius-claw-dashboard.html")
```
No server needed. Works everywhere.

**Option B — Public URL via tunnel (full browser experience)**
If the user wants to open it in their browser, or OpenClaw is on a remote server:
```bash
# From any registered project folder that has genius-server.js:
cd <any-registered-project-path>
node .genius/genius-server.js --tunnel
```
The server auto-detects and starts a tunnel (localtunnel → cloudflared → ngrok).
It prints a public URL like `https://abc123.loca.lt` — send this URL to the user.
State is written to `.genius/memory/server.json`.

**Option C — Local only (OpenClaw running locally)**
```bash
open <workspace>/genius-claw-dashboard.html 2>/dev/null || echo "📂 Open: <workspace>/genius-claw-dashboard.html"
```

### Dashboard structure (per project, when navigating in)
Each project keeps its existing Genius Team dashboard:
- Master view with overall project status
- Tabs for each phase playground (Discovery, Design, Architecture, Dev, QA, Security, Deploy…)

The global dashboard is the entry point; per-project dashboards are unchanged.

---

## 7. Update Genius Team

Check latest version on GitHub:
```bash
LATEST=$(curl -fsSL https://api.github.com/repos/w-3-art/genius-team/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
```

For each project in the registry:
```bash
cd <project-path>
CURRENT=$(cat .genius/VERSION 2>/dev/null || echo "unknown")
if [ "$CURRENT" != "$LATEST" ]; then
  bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/upgrade.sh)
fi
```

Report results: which projects were updated, which were already up to date.

---

## 8. Automatic crons (installed with the plugin)

These run automatically — no manual setup needed:

| Cron | Schedule | Action |
|------|----------|--------|
| Auto-update | Daily 3:00 AM | Check GitHub for new version → upgrade all registered projects → notify |
| Daily brief | Daily 8:00 AM | Post status of all active projects to Discord (phase, last activity, alerts) |
| Stale alert | Daily | Projects with no activity >48h → alert the user |

---

## 9. Cross-project intelligence

- If the user says "do it like in [project X]" → look up project X in the registry, find the relevant pattern in `memory/genius-claw.md`
- Security patterns: if a vulnerability type was found in a project, flag it proactively on new projects
- Phase velocity: track how long each phase takes → help estimate timelines on new projects

---

## 10. Project completion & retro

When a project phase reaches "deploy/done":
1. Generate automatic retro: stack used, duration, key decisions, what worked, what to avoid
2. Append to `memory/genius-claw.md` under `## Retros`
3. Mark project as done in registry (keep for learning, don't delete)

---

## Memory file templates

### `memory/genius-claw.md`
```markdown
# Genius-Claw — Vibe Coding Profile

> Auto-maintained by OpenClaw. Updated after each project session.

## Coding Style
<!-- How the user likes to work: tempo, level of detail, communication style -->

## Universal Rules
<!-- Rules that apply to every project -->

## Anti-Patterns to Avoid
<!-- Things that have caused friction, mistakes to not repeat -->

## Favorite Stack & Tools
<!-- Languages, frameworks, libraries, services the user prefers -->

## Retros
<!-- Learnings from completed projects -->
```

### `memory/genius-claw-projects.json`
```json
[]
```

(Each entry: `{ "name", "path", "version", "phase", "lastActive", "status": "active|done" }`)
