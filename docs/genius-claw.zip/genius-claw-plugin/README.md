# Genius-Claw 🌀

> Genius Team, orchestrated by OpenClaw.

## Install

```bash
openclaw plugins install https://genius.w3art.io/genius-claw.zip
```

## What it does

- **Cross-project memory** — your vibe coding profile persists across every project. No more repeating yourself.
- **Global dashboard** — see all your Genius Team projects in one place, with phase status and progress.
- **Auto-updates** — daily check for new Genius Team versions. All your registered projects stay current automatically.
- **Daily brief** — morning status report on all active projects, stale alerts included.
- **Post-session learning** — after each coding session, learnings are extracted and persisted automatically.

## What it's not

This plugin does not replace Genius Team in your project repos. You still install Genius Team per-project via:
```bash
bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/add.sh)
```

Genius-Claw is the OpenClaw layer on top — it orchestrates, remembers, and connects your projects.

## Learn more

https://genius.w3art.io
