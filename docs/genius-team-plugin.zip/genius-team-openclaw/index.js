// Genius Team OpenClaw Plugin — skills-only, no gateway code needed
// All functionality is provided via SKILL.md loaded into the agent context.

module.exports = {
  register: () => {},
  activate: () => {},
};
