# Genius Team — OpenClaw Plugin

A named agent squad for Echo, Ben's AI assistant.

## Agents

- **Rex** — Deep research and competitive analysis (Opus)
- **Dev** — Code implementation and bug fixes (Sonnet)
- **Plume** — Content writing and social posts (Sonnet)
- **Vigile** — System monitoring and health checks (Haiku)
- **Pixel** — Image prompts and visual briefs (Sonnet)

## Install

```bash
openclaw plugins install /tmp/genius-team-openclaw.zip
```

Or from npm (after publish):
```bash
openclaw plugins install openclaw-genius-team
```

## Usage

Read `skills/genius-team/SKILL.md` for full routing rules and examples.
