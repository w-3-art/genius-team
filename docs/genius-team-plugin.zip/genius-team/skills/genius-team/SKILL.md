---
name: genius-team
description: "Install, upgrade, or manage Genius Team — the AI product team framework for Claude Code. Use when: user asks to install Genius Team on a project, upgrade an existing installation, check project status, open the dashboard, or get help with /genius-* commands. NOT for: running Claude Code itself (use coding-agent skill), or general project work unrelated to Genius Team setup."
---

# Genius Team Manager

Genius Team is an AI product team framework that runs inside Claude Code. It provides 21+ specialized agents (interviewer, architect, QA, security, etc.), file-based memory, and interactive playgrounds for any software project.

**Repo:** https://github.com/w-3-art/genius-team
**Site:** https://genius.w3art.io
**Current version:** v13.0

---

## Install on a new project

```bash
cd /path/to/project
bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/create.sh)
```

For an existing project:
```bash
cd /path/to/project
bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/add.sh)
# Options: --mode cli|ide|omni|dual  --engine claude|codex|dual
```

After install, user opens the project in Claude Code and runs `/genius-start`.

---

## Upgrade existing installation

```bash
cd /path/to/project
bash <(curl -fsSL https://raw.githubusercontent.com/w-3-art/genius-team/main/scripts/upgrade.sh)
# Options: --dry-run (preview), --force (skip git check)
```

Always fetches the latest script from GitHub — never uses a local cached copy.

---

## Check project status

```bash
cat /path/to/project/.genius/state.json
```

Key fields: `version`, `phase`, `currentSkill`, `checkpoints`

---

## Open dashboard

```bash
open /path/to/project/.genius/DASHBOARD.html 2>/dev/null \
  || echo "📂 $(realpath /path/to/project/.genius/DASHBOARD.html)"
```

If DASHBOARD.html doesn't exist yet, user runs `/genius-dashboard` inside Claude Code to generate it.

---

## Claude Code commands (for user reference)

| Command | What it does |
|---------|-------------|
| `/genius-start` | Initialize project, load memory, begin interview |
| `/genius-dashboard` | Generate/refresh master playground dashboard |
| `/genius-upgrade` | Upgrade to latest version (fetches from GitHub) |
| `/status` | Show current phase and task progress |
| `/continue` | Resume from last checkpoint |
| `/memory-status` | Show project memory summary |
| `/guard-check` | Verify GENIUS_GUARD.md compliance |
| `STOP` | Pause autonomous execution |

---

## Workflow for new users

1. Install: `bash <(curl ... add.sh)` or `bash <(curl ... create.sh)`
2. Open project in Claude Code terminal
3. Run `/genius-start` → genius-interviewer asks product questions
4. Each phase completes → checkpoint → next phase auto-starts
5. `/genius-dashboard` at any time → visual hub of all completed phases

---

## Troubleshooting

- **"Already at v13, nothing to do"** after upgrade: run with `--force` flag
- **Upgrade shows wrong version**: run `/genius-upgrade` from inside Claude Code (curls latest script)
- **Dashboard not opening**: run `/genius-dashboard` in Claude Code first to generate it
- **Phase stuck**: run `/guard-check` then `/continue`
